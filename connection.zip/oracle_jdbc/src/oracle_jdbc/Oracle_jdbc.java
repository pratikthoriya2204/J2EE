
package oracle_jdbc;
import java.sql.*;


public class Oracle_jdbc {

    
    public static void main(String[] args) {
        try
        {
            Class.forName("oracle.jdbc.driver.OracleDriver");
             Connection con=DriverManager.getConnection("jdbc:oracle:thin:@127.0.0.1:1521/orcl","scott", "tiger");
             
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery("select * from ora_tab");
             while(rs.next())
             {
                 int id = rs.getInt("pid");
                 String name = rs.getString("pname");
                 int price = rs.getInt("price");
                 
       
                 System.out.print("product id is : " + id + "\n");
                 System.out.print("product name is :" + name + "\n");
                 System.out.print("price is : " + price + "\n");
             }
             rs.close();
             st.close();
             con.close();
            }
            catch(Exception e)
            {
            e.printStackTrace();
            }
    }
   
    
    
}
