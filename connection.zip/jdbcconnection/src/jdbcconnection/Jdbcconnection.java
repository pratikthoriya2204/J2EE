
package jdbcconnection;
import java.sql.*;

public class Jdbcconnection {

    
    public static void main(String[] args) {
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost/jdbc_exe","root","");
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("select * from jdbc_tab");
            while(rs.next())
            {
                int id  = rs.getInt("id");
                String fname = rs.getString("firstname");
                String lname = rs.getString("lastname");
                String email = rs.getString("email");
                
                System.out.print(" ID : " +id+ ",\n" );
                System.out.print("firstname : " +fname +",\n");
                System.out.print("lastname : " +lname +",\n");
                System.out.print("email : " +email +",\n");
            }
            rs.close();;
            con.close();
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
       
    }
    
}
